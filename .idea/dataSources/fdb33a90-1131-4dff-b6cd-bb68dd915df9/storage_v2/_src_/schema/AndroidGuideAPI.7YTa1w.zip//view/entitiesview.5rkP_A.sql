CREATE VIEW entitiesview AS
  SELECT `androidguideapi`.`entities`.`id` AS `id`
  FROM `androidguideapi`.`entities`
  ORDER BY `androidguideapi`.`entities`.`id`;

