CREATE VIEW warningview AS
  SELECT
    `androidguideapi`.`warning`.`id`                AS `id`,
    `androidguideapi`.`warning`.`Relationid`        AS `Relationid`,
    `androidguideapi`.`warning`.`WarningSentenceId` AS `WarningSentenceId`
  FROM `androidguideapi`.`warning`
  ORDER BY `androidguideapi`.`warning`.`Relationid`, `androidguideapi`.`warning`.`WarningSentenceId`;

