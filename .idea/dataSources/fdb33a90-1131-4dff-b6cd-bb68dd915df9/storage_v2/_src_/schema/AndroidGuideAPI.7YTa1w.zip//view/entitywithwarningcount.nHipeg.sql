CREATE VIEW entitywithwarningcount AS
  SELECT
    `androidguideapi`.`entities`.`EntityName`    AS `EntityName`,
    `androidguideapi`.`entities`.`QualifiedName` AS `QualifiedName`,
    count(0)                                     AS `warningcount`
  FROM (`androidguideapi`.`recommandwarning`
    JOIN `androidguideapi`.`entities`)
  WHERE (`androidguideapi`.`recommandwarning`.`EntitiesIndex` = `androidguideapi`.`entities`.`id`)
  GROUP BY `androidguideapi`.`recommandwarning`.`EntitiesIndex`
  ORDER BY `warningcount`;

