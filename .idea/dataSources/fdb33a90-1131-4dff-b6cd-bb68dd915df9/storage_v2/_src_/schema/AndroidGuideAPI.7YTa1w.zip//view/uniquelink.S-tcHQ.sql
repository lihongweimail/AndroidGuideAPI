CREATE VIEW uniquelink AS
  SELECT DISTINCT
    `androidguideapi`.`linkentitysnew`.`entityid`   AS `entityid`,
    `androidguideapi`.`linkentitysnew`.`relationid` AS `relationid`
  FROM `androidguideapi`.`linkentitysnew`;

