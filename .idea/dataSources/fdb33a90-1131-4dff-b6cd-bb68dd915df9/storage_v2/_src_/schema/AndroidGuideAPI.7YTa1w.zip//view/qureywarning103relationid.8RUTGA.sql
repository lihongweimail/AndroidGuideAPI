CREATE VIEW qureywarning103relationid AS
  SELECT `a`.`Relationid` AS `relationid`
  FROM (`androidguideapi`.`warning` `a`
    JOIN (SELECT round(((rand() * ((SELECT max(`androidguideapi`.`warning`.`id`)
                                    FROM `androidguideapi`.`warning`) - (SELECT min(`androidguideapi`.`warning`.`id`)
                                                                         FROM `androidguideapi`.`warning`))) +
                        (SELECT min(`androidguideapi`.`warning`.`id`)
                         FROM `androidguideapi`.`warning`)), 0) AS `id`) `b`)
  WHERE (`a`.`id` >= `b`.`id`)
  ORDER BY `a`.`id`
  LIMIT 103;

