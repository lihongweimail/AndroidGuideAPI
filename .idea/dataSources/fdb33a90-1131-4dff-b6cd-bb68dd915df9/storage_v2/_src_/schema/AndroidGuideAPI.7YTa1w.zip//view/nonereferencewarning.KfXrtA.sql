CREATE VIEW nonereferencewarning AS
  SELECT
    `androidguideapi`.`warning`.`id`                     AS `warningid`,
    `androidguideapi`.`warning`.`WarningTag`             AS `WarningTag`,
    `androidguideapi`.`recommandwarning`.`EntitiesIndex` AS `EntitiesIndex`,
    `androidguideapi`.`entities`.`EntityName`            AS `EntityName`,
    `androidguideapi`.`warning`.`WarningSection`         AS `WarningSection`,
    `androidguideapi`.`warning`.`WarningText`            AS `WarningText`,
    `androidguideapi`.`warning`.`WarningType`            AS `WarningType`,
    `androidguideapi`.`warning`.`WarningURL`             AS `WarningURL`,
    `androidguideapi`.`warning`.`WarningSentenceId`      AS `WarningSentenceId`,
    `androidguideapi`.`warning`.`Relationid`             AS `Relationid`
  FROM ((`androidguideapi`.`warning`
    JOIN `androidguideapi`.`recommandwarning`) JOIN `androidguideapi`.`entities`)
  WHERE ((NOT ((`androidguideapi`.`warning`.`WarningURL` LIKE '%https://developer.android.com/reference%'))) AND
         (`androidguideapi`.`warning`.`id` = `androidguideapi`.`recommandwarning`.`WarningIndex`) AND
         (`androidguideapi`.`entities`.`id` = `androidguideapi`.`recommandwarning`.`EntitiesIndex`))
  ORDER BY `androidguideapi`.`entities`.`EntityName`;

