CREATE VIEW `103relationrandom` AS
  SELECT
    `androidguideapi`.`entitiesrelation`.`id`              AS `id`,
    `androidguideapi`.`entitiesrelation`.`EntityOne`       AS `EntityOne`,
    `androidguideapi`.`entitiesrelation`.`Relation`        AS `Relation`,
    `androidguideapi`.`entitiesrelation`.`EntityTwo`       AS `EntityTwo`,
    `androidguideapi`.`entitiesrelation`.`RelationSection` AS `RelationSection`,
    `androidguideapi`.`entitiesrelation`.`RelationURL`     AS `RelationURL`,
    `androidguideapi`.`entitiesrelation`.`RelationText`    AS `RelationText`,
    `androidguideapi`.`entitiesrelation`.`URLid`           AS `URLid`,
    `androidguideapi`.`entitiesrelation`.`Sentenceid`      AS `Sentenceid`,
    `androidguideapi`.`entitiesrelation`.`Relationid`      AS `Relationid`,
    `androidguideapi`.`entitiesrelation`.`POSinfo`         AS `POSinfo`,
    `androidguideapi`.`entitiesrelation`.`SectionType`     AS `SectionType`
  FROM `androidguideapi`.`entitiesrelation`
  WHERE `androidguideapi`.`entitiesrelation`.`Relationid` IN (SELECT `qureywarning103relationid`.`relationid`
                                                              FROM `androidguideapi`.`qureywarning103relationid`);

