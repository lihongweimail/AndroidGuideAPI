CREATE VIEW entitiesinwarning AS
  SELECT DISTINCT
    `a`.`EntityName`                          AS `EntityOneName`,
    `b`.`EntityName`                          AS `EntityTwoName`,
    `androidguideapi`.`warning`.`WarningType` AS `Warningtype`
  FROM `androidguideapi`.`entities` `a`
    JOIN `androidguideapi`.`entities` `b`
    JOIN `androidguideapi`.`warning`
    JOIN `androidguideapi`.`recommandwarning` `c`
    JOIN `androidguideapi`.`recommandwarning` `d`
    JOIN `androidguideapi`.`entitiesrelation`
  WHERE ((`c`.`WarningIndex` = `d`.`WarningIndex`) AND (`androidguideapi`.`warning`.`id` = `c`.`WarningIndex`) AND
         (`c`.`EntitiesIndex` <> `d`.`EntitiesIndex`) AND (`a`.`id` = `c`.`EntitiesIndex`) AND
         (`b`.`id` = `d`.`EntitiesIndex`) AND (`a`.`id` <> `b`.`id`));

