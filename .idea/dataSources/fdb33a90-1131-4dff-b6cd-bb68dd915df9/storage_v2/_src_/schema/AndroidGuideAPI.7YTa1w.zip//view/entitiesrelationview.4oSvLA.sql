CREATE VIEW entitiesrelationview AS
  SELECT
    `androidguideapi`.`entitiesrelationbackup`.`id`         AS `id`,
    `androidguideapi`.`entitiesrelationbackup`.`Relationid` AS `Relationid`,
    `androidguideapi`.`entitiesrelationbackup`.`Sentenceid` AS `Sentenceid`
  FROM `androidguideapi`.`entitiesrelationbackup`
  ORDER BY `androidguideapi`.`entitiesrelationbackup`.`Relationid`,
    `androidguideapi`.`entitiesrelationbackup`.`Sentenceid`;

