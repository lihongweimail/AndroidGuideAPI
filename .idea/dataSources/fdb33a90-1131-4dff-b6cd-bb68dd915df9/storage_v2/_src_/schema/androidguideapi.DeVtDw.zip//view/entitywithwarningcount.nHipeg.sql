create view entitywithwarningcount as
  select
    `androidguideapi`.`entities`.`EntityName`    AS `EntityName`,
    `androidguideapi`.`entities`.`QualifiedName` AS `QualifiedName`,
    count(0)                                     AS `warningcount`
  from (`androidguideapi`.`recommandwarning`
    join `androidguideapi`.`entities`)
  where (`androidguideapi`.`recommandwarning`.`EntitiesIndex` = `androidguideapi`.`entities`.`id`)
  group by `androidguideapi`.`recommandwarning`.`EntitiesIndex`
  order by `warningcount`;

