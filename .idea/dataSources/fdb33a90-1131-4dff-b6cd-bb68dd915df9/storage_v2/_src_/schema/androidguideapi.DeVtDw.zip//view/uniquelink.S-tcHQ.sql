create view uniquelink as
  select distinct
    `androidguideapi`.`linkentitysnew`.`entityid`   AS `entityid`,
    `androidguideapi`.`linkentitysnew`.`relationid` AS `relationid`
  from `androidguideapi`.`linkentitysnew`;

