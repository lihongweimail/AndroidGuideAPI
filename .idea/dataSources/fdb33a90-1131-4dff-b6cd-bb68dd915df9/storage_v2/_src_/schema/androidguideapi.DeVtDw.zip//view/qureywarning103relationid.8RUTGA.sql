create view qureywarning103relationid as
  select `a`.`Relationid` AS `relationid`
  from (`androidguideapi`.`warning` `a`
    join (select round(((rand() * ((select max(`androidguideapi`.`warning`.`id`)
                                    from `androidguideapi`.`warning`) - (select min(`androidguideapi`.`warning`.`id`)
                                                                         from `androidguideapi`.`warning`))) +
                        (select min(`androidguideapi`.`warning`.`id`)
                         from `androidguideapi`.`warning`)), 0) AS `id`) `b`)
  where (`a`.`id` >= `b`.`id`)
  order by `a`.`id`
  limit 103;

