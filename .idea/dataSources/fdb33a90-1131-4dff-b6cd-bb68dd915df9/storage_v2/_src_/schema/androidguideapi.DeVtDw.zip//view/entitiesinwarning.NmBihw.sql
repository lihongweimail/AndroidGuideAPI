create view entitiesinwarning as
  select distinct
    `a`.`EntityName`                          AS `EntityOneName`,
    `b`.`EntityName`                          AS `EntityTwoName`,
    `androidguideapi`.`warning`.`WarningType` AS `Warningtype`
  from `androidguideapi`.`entities` `a`
    join `androidguideapi`.`entities` `b`
    join `androidguideapi`.`warning`
    join `androidguideapi`.`recommandwarning` `c`
    join `androidguideapi`.`recommandwarning` `d`
    join `androidguideapi`.`entitiesrelation`
  where ((`c`.`WarningIndex` = `d`.`WarningIndex`) and (`androidguideapi`.`warning`.`id` = `c`.`WarningIndex`) and
         (`c`.`EntitiesIndex` <> `d`.`EntitiesIndex`) and (`a`.`id` = `c`.`EntitiesIndex`) and
         (`b`.`id` = `d`.`EntitiesIndex`) and (`a`.`id` <> `b`.`id`));

