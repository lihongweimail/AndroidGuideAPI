create view warningview as
  select
    `androidguideapi`.`warning`.`id`                AS `id`,
    `androidguideapi`.`warning`.`Relationid`        AS `Relationid`,
    `androidguideapi`.`warning`.`WarningSentenceId` AS `WarningSentenceId`
  from `androidguideapi`.`warning`
  order by `androidguideapi`.`warning`.`Relationid`, `androidguideapi`.`warning`.`WarningSentenceId`;

