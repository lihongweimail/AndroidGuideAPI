create view nonereferencewarning as
  select
    `androidguideapi`.`warning`.`id`                     AS `warningid`,
    `androidguideapi`.`warning`.`WarningTag`             AS `WarningTag`,
    `androidguideapi`.`recommandwarning`.`EntitiesIndex` AS `EntitiesIndex`,
    `androidguideapi`.`entities`.`EntityName`            AS `EntityName`,
    `androidguideapi`.`warning`.`WarningSection`         AS `WarningSection`,
    `androidguideapi`.`warning`.`WarningText`            AS `WarningText`,
    `androidguideapi`.`warning`.`WarningType`            AS `WarningType`,
    `androidguideapi`.`warning`.`WarningURL`             AS `WarningURL`,
    `androidguideapi`.`warning`.`WarningSentenceId`      AS `WarningSentenceId`,
    `androidguideapi`.`warning`.`Relationid`             AS `Relationid`
  from ((`androidguideapi`.`warning`
    join `androidguideapi`.`recommandwarning`) join `androidguideapi`.`entities`)
  where ((not ((`androidguideapi`.`warning`.`WarningURL` like '%https://developer.android.com/reference%'))) and
         (`androidguideapi`.`warning`.`id` = `androidguideapi`.`recommandwarning`.`WarningIndex`) and
         (`androidguideapi`.`entities`.`id` = `androidguideapi`.`recommandwarning`.`EntitiesIndex`))
  order by `androidguideapi`.`entities`.`EntityName`;

