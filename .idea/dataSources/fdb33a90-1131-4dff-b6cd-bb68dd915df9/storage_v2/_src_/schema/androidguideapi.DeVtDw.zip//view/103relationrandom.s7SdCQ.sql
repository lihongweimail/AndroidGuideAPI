create view `103relationrandom` as
  select
    `androidguideapi`.`entitiesrelation`.`id`              AS `id`,
    `androidguideapi`.`entitiesrelation`.`EntityOne`       AS `EntityOne`,
    `androidguideapi`.`entitiesrelation`.`Relation`        AS `Relation`,
    `androidguideapi`.`entitiesrelation`.`EntityTwo`       AS `EntityTwo`,
    `androidguideapi`.`entitiesrelation`.`RelationSection` AS `RelationSection`,
    `androidguideapi`.`entitiesrelation`.`RelationURL`     AS `RelationURL`,
    `androidguideapi`.`entitiesrelation`.`RelationText`    AS `RelationText`,
    `androidguideapi`.`entitiesrelation`.`URLid`           AS `URLid`,
    `androidguideapi`.`entitiesrelation`.`Sentenceid`      AS `Sentenceid`,
    `androidguideapi`.`entitiesrelation`.`Relationid`      AS `Relationid`,
    `androidguideapi`.`entitiesrelation`.`POSinfo`         AS `POSinfo`,
    `androidguideapi`.`entitiesrelation`.`SectionType`     AS `SectionType`
  from `androidguideapi`.`entitiesrelation`
  where `androidguideapi`.`entitiesrelation`.`Relationid` in (select `qureywarning103relationid`.`relationid`
                                                              from `androidguideapi`.`qureywarning103relationid`);

