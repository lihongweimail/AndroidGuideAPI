create view entitiesview as
  select `androidguideapi`.`entities`.`id` AS `id`
  from `androidguideapi`.`entities`
  order by `androidguideapi`.`entities`.`id`;

