create view entitiesrelationview as
  select
    `androidguideapi`.`entitiesrelationbackup`.`id`         AS `id`,
    `androidguideapi`.`entitiesrelationbackup`.`Relationid` AS `Relationid`,
    `androidguideapi`.`entitiesrelationbackup`.`Sentenceid` AS `Sentenceid`
  from `androidguideapi`.`entitiesrelationbackup`
  order by `androidguideapi`.`entitiesrelationbackup`.`Relationid`,
    `androidguideapi`.`entitiesrelationbackup`.`Sentenceid`;

